## simplified alternative setup for nextcloud and onlyoffice

### Tutorial: install nextcloud and onlyoffice with snap, apt for nginx with manual configuration
#### including nginx and configuring

[snap nextcloud with nginx reverse proxy](https://www.nicemicro.com/tutorials/debian-snap-nextcloud.html)

#### adding nextcloud
[add onlyoffice](https://www.nicemicro.com/tutorials/debian-snap-onlyoffice.html)